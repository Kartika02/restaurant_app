mport 'package:flutter/widgets.dart';

class PayloadProvider extends ChangeNotifier {
  String? payload;

  PayloadProvider({
    this.payload,
  });
}